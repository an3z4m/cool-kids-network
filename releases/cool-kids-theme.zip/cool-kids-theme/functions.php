<?php
function cool_kids_theme_setup() {
    // Add support for custom menus, title tag, etc.
    add_theme_support('title-tag');
}

add_action('after_setup_theme', 'cool_kids_theme_setup');

function cool_kids_enqueue_assets() {
    // Enqueue theme stylesheet
    wp_enqueue_style('cool-kids-theme-style', get_stylesheet_uri());

    // Enqueue custom JS (optional)
    // wp_enqueue_script('cool-kids-theme-js', get_template_directory_uri() . '/assets/js/main.js', [], false, true);
}

add_action('wp_enqueue_scripts', 'cool_kids_enqueue_assets');
?>