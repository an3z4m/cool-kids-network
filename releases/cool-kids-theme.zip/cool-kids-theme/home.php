<?php get_header(); ?>
<?php echo do_shortcode('[cool_kids_network]'); ?>
<?php get_footer(); ?>