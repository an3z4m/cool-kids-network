<?php
/* Template Name: Login Template */

get_header(); ?>

    <h2>Login</h2>
    <?php echo do_shortcode('[cool_kids_login]'); ?>

<?php get_footer(); ?>