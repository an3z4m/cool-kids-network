<?php
/* Template Name: User List Template */

get_header(); ?>

    <h2>User List</h2>
    <?php echo do_shortcode('[cool_kids_user_list]'); ?>

<?php get_footer(); ?>