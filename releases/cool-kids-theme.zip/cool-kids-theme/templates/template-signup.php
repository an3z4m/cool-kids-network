<?php
/* Template Name: Signup Template */

get_header(); ?>

    <h2>Sign Up</h2>
    <?php echo do_shortcode('[cool_kids_signup]'); ?>

<?php get_footer(); ?>