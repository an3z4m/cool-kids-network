<?php
/* Template Name: Profile Template */

get_header(); ?>

    <h2>Your Profile</h2>
    <?php echo do_shortcode('[cool_kids_profile]'); ?>

<?php get_footer(); ?>