</main>
    <footer>
        <div class="container">
            <p>&copy; 2024 Cool Kids Network. All Rights Reserved.</p>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>