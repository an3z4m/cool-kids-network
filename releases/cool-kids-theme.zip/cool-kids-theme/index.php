<?php get_header(); ?>
    <h1>Welcome to the Cool Kids Network</h1>
    <p>This is the fallback template for the Cool Kids Optional Theme.</p>

    <?php
    if (have_posts()) :
        while (have_posts()) : the_post(); ?>
           <h2><?php the_title(); ?></h2>
           <div><?php the_content(); ?></div>
        <?php 
        endwhile; else : ?>
        <p>Sorry, no content is available.</p>
    <?php 
endif; ?>

<?php get_footer(); ?>