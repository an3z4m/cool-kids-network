<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header>
        <h1><a href="<?php echo home_url(); ?>">Cool Kids Network</a></h1>
        <nav>
            <ul>
            <?php
                if ( has_nav_menu( 'primary' ) ) {
                    wp_nav_menu( array(
                        'theme_location' => 'primary',
                        'container'      => false, // Remove the div container around the menu
                        'items_wrap'     => '%3$s', // Remove the surrounding <ul> added by wp_nav_menu
                        'fallback_cb'    => false // No fallback in case there's no menu set
                    ) );
                }
                if (is_user_logged_in()): 
                ?>
                   <li><a href="<?php echo wp_logout_url(home_url()); ?>">Logout</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <main class="container">